// commented solution for websocket
///////////////////////////////////////////////////////////

// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import io from 'socket.io-client'

// const id =Math.floor(Math.random()*1000)
// const socket=io.connect('http://127.0.0.1:9000');

// const App =(props)=>{
// const [messages,setMessages] = useState([]);
// const [input,setInput] = useState('');
// const [inputName,setInputName] = useState('');


// useEffect(()=>{
// socket.on('new-message',(msg)=>{setMessages(messages=>messages.concat(msg))
// console.log(messages)})
//  },[]);

   
// const handleChange=(e) =>{
//   const {target :{value}}=e;
//   setInput(value);
// }
// const handleChangeName=(e) =>{
//   const {target :{value}}=e;
//   setInputName(value);
// }
// const handleSubmit=(e)=>{
//   e.preventDefault();
//   socket.emit('message',{content:input,Name:inputName});
//   setInput('');
//   setInputName('');

// }

// return (
//   <div>
//     <form id ="form" onSubmit={handleSubmit}>
//       <input type="text" name="Name" onChange={handleChangeName} value={inputName}/>
//       <input type="text" name="content" onChange={handleChange} value={input}/>
//         <button type="submit">Send</button>
//     </form>
//   <div>
//     {
//       messages.map(message =><div key={message.content}><h1>{message.Name}:{message.content}</h1></div>)
//     }
//     </div>
//     </div>
// )

// } 
// export default App;
/////////////////////////////////////////////////////////////
// uncommented solution for eventsource
import React, { useState, useEffect } from "react";
import axios from "axios";


const App =(props)=>{
const [messages,setMessages] = useState([]);
const [input,setInput] = useState('');
const [inputName,setInputName] = useState('');


useEffect(()=>{

const eventSource= new EventSource('http://127.0.0.1:9000/response');
eventSource.onmessage = (e)=>{
  
  const data = JSON.parse(e.data);
  setMessages(messages=>messages.concat(data));
}
 }
 ,[]);

   
const handleChange=(e) =>{
  const {target :{value}}=e;
  setInput(value);
}
const handleChangeName=(e) =>{
  const {target :{value}}=e;
  setInputName(value);
}
const handleSubmit=(e)=>{
  e.preventDefault();

axios.post('http://127.0.0.1:9000/messagesSend',{content:input, Name:inputName
}).then(()=>{ setInput('');setInputName('')})
}

return (
  <div>
    <form id ="form" onSubmit={handleSubmit}>
      <input type="text" name="Name" onChange={handleChangeName} value={inputName}/>
      <input type="text" name="content" onChange={handleChange} value={input}/>
        <button type="submit">Send</button>
    </form>
  <div>
    {
      messages.map(message =><div key={message.content}><h1>{message.Name}:{message.content}</h1></div>)
    }
    </div>
    </div>
)

} 
export default App;