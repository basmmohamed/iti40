// commented solution for web socket
/////////////////////////////////////////////////////
// const express =  require('express');
// const cors = require ('cors');
// const app = express();
// const socket=require('socket.io');
// const server =require('http').Server(app)
// app.use(express.json());//middleware
// app.use(cors());//middleware
// const io = socket(server);

// io.on('connection',(client)=>{
//     client.on('message',(message)=>{console.log(message);
// io.emit('new-message',message);
//     })
// })

// const PORT = process.env.PORT || 5000;
// server.listen(PORT,(err)=>{if (!err)
// console.log(`started server on port ${PORT}`);
// });

/////////////////////////////////////////////////////////
// uncommented solution for eventsource
const express =  require('express');
const cors = require ('cors');
const app = express();

app.use(express.json());//middleware
app.use(cors());//middleware


const responses={}

app.get('/response',(req,res)=>{
    const id = Math.floor(Math.random()*1000);//to have a unique id as the other one give the same id so only one user can send and recieve both messages
    // const {id}=req.body;
    req.on('close',()=>delete responses[id])
    res.writeHead(200,{
        'Content-Type':'text/event-stream',
        'Cache-Control':'no-cache',
        Connection:'keep-alive',
    });
    responses[id]=res;
    console.log(id);  
})

app.post('/messagesSend',(req,res)=>{
    const {body}=req;
    Object.keys(responses).forEach(messageId=>
        {
            responses[messageId].write(`data: ${JSON.stringify(body)}\n\n`)
})
    res.status(204).end();  
})




const PORT = process.env.PORT || 5000;
app.listen(PORT,(err)=>{if (!err)
console.log(`started server on port ${PORT}`);
});