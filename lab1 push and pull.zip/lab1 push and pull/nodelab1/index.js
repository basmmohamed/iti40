////////////////////////////////////////////////////////
// const express =  require('express');
// const cors = require ('cors');
// const app = express();

// app.use(express.json());//middleware
// app.use(cors());//middleware

// const responses=[];

// app.post('/messages',(req,res)=>{
//     const {body} =req;
//     responses.push(body);
//     console.log('NEw message',body.content);
//     res.status(204).end();
// });
// app.get('/messages',(req,res)=>{
//     res.json(responses);
// });
// const PORT = process.env.PORT || 5000;
// app.listen(PORT,(err)=>{if (!err)
// console.log(`started server on port ${PORT}`);
// });
////////////////////////////////////////////////////////////
const express =  require('express');
const cors = require ('cors');
const app = express();

app.use(express.json());//middleware
app.use(cors());//middleware

const messages=[];

app.post('/messages',(req,res)=>{
    const {body} =req;
    messages.push(body);
    console.log('NEw message',body.content);
    res.status(204).end();
});
app.get('/messages',(req,res)=>{
    res.json(messages);
});


const responses=[]
app.post('/response',(req,res)=>{
    const {id}=req.body;
    req.on('close',()=>delete responses[id])
    responses[id]=res;

    console.log(id);
    
})
app.post('/messagesSend',(req,res)=>{
    const {body}=req;
    Object.keys(responses).forEach(messageId=>{responses[messageId].json(body)
    delete responses[messageId];})
    res.status(204).end();
    
})




const PORT = process.env.PORT || 5000;
app.listen(PORT,(err)=>{if (!err)
console.log(`started server on port ${PORT}`);
});