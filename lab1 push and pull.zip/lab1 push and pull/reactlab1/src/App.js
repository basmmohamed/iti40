
// import React, { useState, useEffect } from "react";
// import axios from "axios";

// const App =()=>{
// const [messages,setMessages] = useState([]);
// const [input,setInput] = useState('');
// const [inputName,setInputName] = useState('');


// useEffect(()=>{
//   setInterval(()=>axios.get('http://127.0.0.1:9000/messages').then((res)=>{
//     setMessages(res.data)}),5*1000)},[]);

   
// const handleChange=(e) =>{
//   const {target :{value}}=e;
//   setInput(value);
// }
// const handleChangeName=(e) =>{
//   const {target :{value}}=e;
//   setInputName(value);
// }
// const handleSubmit=(e)=>{
//   e.preventDefault();
//   axios.post('http://127.0.0.1:9000/messages',{content:input
//   ,Name:inputName
// })
// }

// return (
//   <div>
//     <form id ="form" onSubmit={handleSubmit}>
//     <input type="text" name="Name" onChange={handleChangeName} value={inputName}/>

//       <input type="text" name="content" onChange={handleChange} value={input}/>
//         <button type="submit">Send</button>
//     </form>
//   <div>
//     {
//       messages.map(message =><div key={message.content}><h1>{message.Name}:{message.content}</h1></div>)
//     }
//     </div>
//     </div>
// )

// } 
// export default App;




import React, { useState, useEffect } from "react";
import axios from "axios";
const id =Math.floor(Math.random()*1000)
const App =(props)=>{
const [messages,setMessages] = useState([]);
const [input,setInput] = useState('');
const [inputName,setInputName] = useState('');


useEffect(()=>{
  const subscribe =(messages)=>  axios.post('http://127.0.0.1:9000/response',{id}).then((res)=>{
    console.log(res.data);
    console.log(messages);
  const newMessage= messages.concat(res.data);
  setMessages(newMessage);
  subscribe(newMessage);//as recursive inside useEffect
  
    
});
subscribe(messages);
 },[]);

   
const handleChange=(e) =>{
  const {target :{value}}=e;
  setInput(value);
}
const handleChangeName=(e) =>{
  const {target :{value}}=e;
  setInputName(value);
}
const handleSubmit=(e)=>{
  e.preventDefault();
  axios.post('http://127.0.0.1:9000/messagesSend',{content:input
  ,Name:inputName
});
}

return (
  <div>
    <form id ="form" onSubmit={handleSubmit}>
      <input type="text" name="Name" onChange={handleChangeName} value={inputName}/>
      <input type="text" name="content" onChange={handleChange} value={input}/>
        <button type="submit">Send</button>
    </form>
  <div>
    {
      messages.map(message =><div key={message.content}><h1>{message.Name}:{message.content}</h1></div>)
    }
    </div>
    </div>
)

} 
export default App;